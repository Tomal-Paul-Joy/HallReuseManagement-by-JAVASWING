

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ASUS
 */

import java.awt.FlowLayout;
import java.awt.Graphics2D;
    import java.sql.*;
import javax.swing.JOptionPane;
 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileNameExtensionFilter;
public class Adddmin extends javax.swing.JFrame {

    /**
     * Creates new form Adddmin
     */
     File f = null ; 
    String path = null ; 
    private ImageIcon format = null ; 
    String fname = null ; 
    int s =0 ; 
    byte[] pimage = null ; 
    
    ResultSet rs ; 
     Connection con = null;
    PreparedStatement pst = null;

    public Adddmin() {
        initComponents();
        //setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("Product Images");
        txtbill.setText("Hall reused material : "+ "\n"+"Contact name: 01865161220"+"\n");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Initialize jLabel1 and jLabel2
        
        

        // Initialize the database connection (you need to set this up)
        con = initializeDatabaseConnection();

        // Retrieve and display images from the database
        displayImagesFromDatabase();
       
        con = NewClass.con() ; 
        update() ; 
        update2(); 
    }
     private Connection initializeDatabaseConnection() {
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
            //JOptionPane.showMessageDialog(null,"Connected" );
        }
        
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Wrong");
        }
       return con;

 
         
         
         
         
    }
      private void displayImagesFromDatabase() {
        try {
            // Execute a SQL query to fetch product data (image, product name, etc.) from your database
            String query = "SELECT ImageFile, ProductCode FROM record";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            rs = preparedStatement.executeQuery();

            // Display the first image in jLabel1
             if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic1.setIcon(new ImageIcon(scaledImage));
                 jTextField1.setText(rs.getString("ProductCode"));
            }
              if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic2.setIcon(new ImageIcon(scaledImage));
                 jTextField2.setText(rs.getString("ProductCode"));
            }
               if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic3.setIcon(new ImageIcon(scaledImage));
                 jTextField3.setText(rs.getString("ProductCode"));
            }
                if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic4.setIcon(new ImageIcon(scaledImage));
                 jTextField4.setText(rs.getString("ProductCode"));
            }
                 if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic5.setIcon(new ImageIcon(scaledImage));
                 jTextField5.setText(rs.getString("ProductCode"));
            }
            if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic6.setIcon(new ImageIcon(scaledImage));
                jTextField6.setText(rs.getString("ProductCode"));
            }

            // Display the second image in jLabel2 if available
            if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic7.setIcon(new ImageIcon(scaledImage));
                 jTextField7.setText(rs.getString("ProductCode"));
            }
              if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic8.setIcon(new ImageIcon(scaledImage));
                 jTextField8.setText(rs.getString("ProductCode"));
            }
               if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic9.setIcon(new ImageIcon(scaledImage));
                 jTextField9.setText(rs.getString("ProductCode"));
            }

            preparedStatement.close();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
        


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        Search1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        Tab1 = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        ProductCode2 = new javax.swing.JTextField();
        ProductName1 = new javax.swing.JTextField();
        Quantity1 = new javax.swing.JTextField();
        Price1 = new javax.swing.JTextField();
        Duration2 = new javax.swing.JTextField();
        StudentID = new javax.swing.JTextField();
        add = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtbill = new javax.swing.JTextArea();
        print = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        ProductName = new javax.swing.JTextField();
        Quantity = new javax.swing.JTextField();
        Duration = new javax.swing.JTextField();
        Price = new javax.swing.JTextField();
        ImageLabel = new javax.swing.JLabel();
        ImagePath = new javax.swing.JTextField();
        ImageName = new javax.swing.JTextField();
        Insert = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        Search = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tab = new javax.swing.JTable();
        Browse = new javax.swing.JButton();
        ProductCode = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        pic1 = new javax.swing.JLabel();
        pic3 = new javax.swing.JLabel();
        pic7 = new javax.swing.JLabel();
        pic8 = new javax.swing.JLabel();
        pic2 = new javax.swing.JLabel();
        pic4 = new javax.swing.JLabel();
        pic5 = new javax.swing.JLabel();
        pic9 = new javax.swing.JLabel();
        pic6 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        Search2 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTabbedPane1.setForeground(new java.awt.Color(13, 13, 189));
        jTabbedPane1.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane1.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Search1.setBackground(new java.awt.Color(204, 255, 153));
        Search1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search1ActionPerformed(evt);
            }
        });
        Search1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Search1KeyReleased(evt);
            }
        });
        jPanel3.add(Search1, new org.netbeans.lib.awtextra.AbsoluteConstraints(559, 40, 320, -1));

        jButton1.setBackground(new java.awt.Color(204, 255, 102));
        jButton1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton1.setText("Accept");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1270, 400, -1, 30));

        jScrollPane2.setBackground(new java.awt.Color(204, 255, 102));

        Tab1.setBackground(new java.awt.Color(204, 255, 153));
        Tab1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "SellerID", "ProductName", "Quantity", "Price", "Duration", "StudentID"
            }
        ));
        Tab1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Tab1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(Tab1);

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 1380, 230));

        jButton2.setBackground(new java.awt.Color(204, 255, 51));
        jButton2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton2.setText("Remove");
        jPanel3.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 403, -1, 30));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Search");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 40, 76, 20));

        ProductCode2.setBackground(new java.awt.Color(204, 255, 153));
        ProductCode2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductCode2ActionPerformed(evt);
            }
        });
        jPanel3.add(ProductCode2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 500, 170, 30));

        ProductName1.setBackground(new java.awt.Color(204, 255, 153));
        ProductName1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductName1ActionPerformed(evt);
            }
        });
        jPanel3.add(ProductName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 540, 170, 30));

        Quantity1.setBackground(new java.awt.Color(204, 255, 153));
        jPanel3.add(Quantity1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 580, 170, 30));

        Price1.setBackground(new java.awt.Color(204, 255, 153));
        Price1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Price1ActionPerformed(evt);
            }
        });
        jPanel3.add(Price1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 620, 170, 30));

        Duration2.setBackground(new java.awt.Color(204, 255, 153));
        jPanel3.add(Duration2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 660, 170, 30));

        StudentID.setBackground(new java.awt.Color(204, 255, 153));
        StudentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentIDActionPerformed(evt);
            }
        });
        jPanel3.add(StudentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 700, 170, 30));

        add.setBackground(new java.awt.Color(204, 255, 51));
        add.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        add.setText("Add");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        jPanel3.add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 710, -1, -1));

        txtbill.setColumns(20);
        txtbill.setRows(5);
        jScrollPane3.setViewportView(txtbill);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 460, 320, 270));

        print.setBackground(new java.awt.Color(204, 255, 102));
        print.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        print.setText("Print");
        print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printActionPerformed(evt);
            }
        });
        jPanel3.add(print, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 710, -1, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Product Name");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 540, 130, 30));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Quantity");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 580, 130, 30));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Price");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 620, 130, 30));

        jLabel23.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Duration");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 660, 130, 30));

        jLabel24.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Student ID");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 700, 130, 30));

        jLabel25.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Product Code");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 130, 30));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/green.png"))); // NOI18N
        jPanel3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1380, 760));

        jTabbedPane1.addTab("Requests", jPanel3);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ProductName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductNameActionPerformed(evt);
            }
        });
        jPanel2.add(ProductName, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 153, -1));

        Quantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                QuantityActionPerformed(evt);
            }
        });
        jPanel2.add(Quantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 80, 153, -1));
        jPanel2.add(Duration, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 153, -1));
        jPanel2.add(Price, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 153, -1));
        jPanel2.add(ImageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(970, 60, 220, 200));

        ImagePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImagePathActionPerformed(evt);
            }
        });
        jPanel2.add(ImagePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 30, 187, -1));

        ImageName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImageNameActionPerformed(evt);
            }
        });
        jPanel2.add(ImageName, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 300, 187, -1));

        Insert.setBackground(new java.awt.Color(51, 51, 255));
        Insert.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        Insert.setForeground(new java.awt.Color(255, 255, 255));
        Insert.setText("Insert");
        Insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertActionPerformed(evt);
            }
        });
        jPanel2.add(Insert, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, 30));

        Update.setBackground(new java.awt.Color(51, 51, 255));
        Update.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        Update.setForeground(new java.awt.Color(255, 255, 255));
        Update.setText("Update");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        jPanel2.add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 220, -1, 30));

        Delete.setBackground(new java.awt.Color(51, 51, 255));
        Delete.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        Delete.setForeground(new java.awt.Color(255, 255, 255));
        Delete.setText("Delete");
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        jPanel2.add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 220, -1, 30));

        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        Search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                SearchKeyReleased(evt);
            }
        });
        jPanel2.add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 300, 310, 30));

        Tab.setBackground(new java.awt.Color(51, 51, 0));
        Tab.setForeground(new java.awt.Color(255, 255, 255));
        Tab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "SellerID", "ProductName", "Quantity", "Price", "Duration"
            }
        ));
        Tab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Tab);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 360, 1240, 380));

        Browse.setBackground(new java.awt.Color(51, 51, 255));
        Browse.setText("Browse");
        Browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BrowseActionPerformed(evt);
            }
        });
        jPanel2.add(Browse, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 300, -1, -1));
        jPanel2.add(ProductCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, 153, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("SellerID");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 20, 90, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Product Name");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Quantity");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 80, 82, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Price");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 82, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Duration");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, 110, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Search");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 300, 60, 30));

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/green.png"))); // NOI18N
        jPanel2.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(5, 0, 1320, 760));

        jTabbedPane1.addTab("Record", jPanel2);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pic1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic1MouseClicked(evt);
            }
        });
        jPanel4.add(pic1, new org.netbeans.lib.awtextra.AbsoluteConstraints(122, 53, 199, 178));

        pic3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic3MouseClicked(evt);
            }
        });
        jPanel4.add(pic3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1066, 53, 197, 178));

        pic7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic7MouseClicked(evt);
            }
        });
        jPanel4.add(pic7, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 523, 185, 176));

        pic8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic8MouseClicked(evt);
            }
        });
        jPanel4.add(pic8, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 523, 198, 167));

        pic2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic2MouseClicked(evt);
            }
        });
        jPanel4.add(pic2, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 53, 198, 178));

        pic4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic4MouseClicked(evt);
            }
        });
        jPanel4.add(pic4, new org.netbeans.lib.awtextra.AbsoluteConstraints(149, 293, 185, 178));

        pic5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic5MouseClicked(evt);
            }
        });
        jPanel4.add(pic5, new org.netbeans.lib.awtextra.AbsoluteConstraints(589, 305, 198, 169));

        pic9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic9MouseClicked(evt);
            }
        });
        jPanel4.add(pic9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1066, 523, 197, 183));

        pic6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic6MouseClicked(evt);
            }
        });
        jPanel4.add(pic6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1066, 305, 197, 178));

        jTextField1.setText("jTextField1");
        jPanel4.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(221, 237, 100, -1));

        jTextField2.setText("jTextField2");
        jPanel4.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(686, 237, 101, -1));

        jTextField3.setText("jTextField3");
        jPanel4.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1164, 237, 99, -1));

        jTextField4.setText("jTextField4");
        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(234, 489, 100, -1));

        jTextField5.setText("jTextField5");
        jPanel4.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(686, 489, 101, -1));

        jTextField6.setText("jTextField6");
        jPanel4.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(1164, 489, 99, -1));

        jTextField7.setText("jTextField7");
        jPanel4.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 720, 99, -1));

        jTextField8.setText("jTextField8");
        jPanel4.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 720, 101, -1));

        jTextField9.setText("jTextField9");
        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 720, 94, -1));

        Search2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search2ActionPerformed(evt);
            }
        });
        Search2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Search2KeyReleased(evt);
            }
        });
        jPanel4.add(Search2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 10, 406, -1));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Product Code:");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 490, 90, 20));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Product Code:");
        jPanel4.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 240, 90, 20));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Product Code:");
        jPanel4.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 490, 90, 20));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Product Code:");
        jPanel4.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 240, 90, 20));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Product Code:");
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 240, 90, 20));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Product Code:");
        jPanel4.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 720, 90, 20));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Product Code:");
        jPanel4.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 720, 90, 20));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Product Code:");
        jPanel4.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 720, 90, 20));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Product Code:");
        jPanel4.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 490, 90, 20));

        jLabel20.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Search Here");
        jPanel4.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 10, -1, 20));

        jButton3.setBackground(new java.awt.Color(255, 0, 51));
        jButton3.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jButton3.setText("Exit");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1250, 10, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/green.png"))); // NOI18N
        jPanel4.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 1330, 760));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -5, 1380, 760));

        jTabbedPane1.addTab("Home", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1448, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

  
    private void ProductNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductNameActionPerformed
 
    private void ImagePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImagePathActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ImagePathActionPerformed

    private void InsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertActionPerformed
        // TODO add your handling code here:
           System.out.print("Image Path - "+path); 
        System.out.print("Image Name - "+ f.getName());
        File f = new File(path); 
            try 
        { 
            InputStream is = new FileInputStream(f); 
            pst = con.prepareStatement("INSERT INTO record(ProductCode,ProductName,Quantity,Price,Duration,ImagePath,ImageName,ImageFile)VALUES(?,?,?,?,?,?,?,?)"); 
            pst.setString(1,ProductCode.getText()); 
            pst.setString(2,ProductName.getText());
            
            pst.setString(3, Quantity.getText()); 
            pst.setString(4,Price.getText()); 
            pst.setString(5,Duration.getText()); 
            pst.setString(6, path);
            pst.setString(7, f.getName());
            
            pst.setBlob(8,is ); 
            int inserted = pst.executeUpdate(); 
            if (inserted>0) 
            {
                JOptionPane.showMessageDialog(null, "Successfully Inserted"); 
                update() ; 
            }
            
            
            }
     catch (Exception e) {
    e.printStackTrace();
}
    }//GEN-LAST:event_InsertActionPerformed

    private void BrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BrowseActionPerformed
        // TODO add your handling code here:
          JFileChooser filechooser = new JFileChooser() ; 
        FileNameExtensionFilter fnwf = new FileNameExtensionFilter("PNG JPG AND JPEG","png","jpeg","jpg"); 
        filechooser.addChoosableFileFilter(fnwf);
        int load = filechooser.showOpenDialog(null); 
        if (load == filechooser.APPROVE_OPTION ) 
        { 
            f = filechooser.getSelectedFile(); 
            path = f.getAbsolutePath(); 
            ImagePath.setText(path); 
            ImageIcon ii = new ImageIcon(path); 
            Image img = ii.getImage().getScaledInstance(200,200,Image.SCALE_SMOOTH); 
            ImageLabel.setIcon(new ImageIcon(img)); 
            
        }
    }//GEN-LAST:event_BrowseActionPerformed

    private void ImageNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImageNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ImageNameActionPerformed

    private void TabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabMouseClicked
        // TODO add your handling code here:
     int id = Integer.parseInt(Tab.getValueAt(Tab.getSelectedRow(),0).toString()); 
      try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    String jdbcUrl = "jdbc:mysql://localhost:3306/db";
    String dbUser = "root";
    String dbPassword = "";

    try (Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
         PreparedStatement ps = con.prepareStatement("SELECT * FROM record WHERE ProductCode="+id);
         ResultSet res = ps.executeQuery()) {

        while (res.next()) {
            
            ProductCode.setText(res.getString("ProductCode"));
            ProductName.setText(res.getString("ProductName"));
           // ImageName.setText(res.getString("ImageName"));
           Quantity.setText(res.getString("Quantity"));
           Price.setText(res.getString("Price"));
           Duration.setText(res.getString("Duration")); 
            ImagePath.setText(res.getString("ImagePath")); 
             byte[] imagedata = res.getBytes("ImageFile"); 
             format = new ImageIcon(imagedata); 
             Image mm = format.getImage(); 
             Image img2 = mm.getScaledInstance(200, 200, Image.SCALE_SMOOTH); 
             ImageIcon image = new ImageIcon(img2); 
             ImageLabel.setIcon(image);
             
          
        }
    }
} catch (Exception e) {
    e.printStackTrace();
}

    }//GEN-LAST:event_TabMouseClicked

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        // TODO add your handling code here:
          int id = Integer.parseInt(Tab.getValueAt(Tab.getSelectedRow(),0).toString()); 
               
      try {
           
    Class.forName("com.mysql.cj.jdbc.Driver");
    String jdbcUrl = "jdbc:mysql://localhost:3306/db";
    String dbUser = "root";
    String dbPassword = "";
    Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
    Statement st = con.createStatement() ; 
    int r = JOptionPane.showConfirmDialog(this,"are you sure to delete this "); 
   if (r==0) { 
       if (!st.execute("delete from record where ProductCode="+id)) { 
           update() ; 
           
       
       }
       else JOptionPane.showMessageDialog(this,"try again");
       }
   
     
            
            
        }
      catch (Exception e) {
    e.printStackTrace();
}
    }//GEN-LAST:event_DeleteActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        // TODO add your handling code here:
        System.out.println("Image Path - " + path);
System.out.println("Image Name - " + f.getName());
File f = new File(path);

try {
    int id = Integer.parseInt(Tab.getValueAt(Tab.getSelectedRow(), 0).toString());

    Class.forName("com.mysql.cj.jdbc.Driver");
    String jdbcUrl = "jdbc:mysql://localhost:3306/db";
    String dbUser = "root";
    String dbPassword = "";
    Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

    // Assuming that StudentID is an integer; adjust the data type accordingly
    int productCode = Integer.parseInt(ProductCode.getText());

    String updateQuery = "UPDATE record SET ProductCode=?, ProductName=?, Quantity=?,Price=?,Duration=?,ImagePath=?,ImageName=?, ImageFile=? WHERE ProductCode=?";
    PreparedStatement pst = con.prepareStatement(updateQuery);

    pst.setInt(1, productCode);
    pst.setString(2, ProductName.getText());
    pst.setString(3,Quantity.getText()); 
    pst.setString(4,Price.getText()); 
    pst.setString(5,Duration.getText());
 
    pst.setString(6, ImagePath.getText());
       pst.setString(7, f.getName());

    // To handle the ImageFile column as a BLOB, you should use setBinaryStream
    pst.setBinaryStream(8, new FileInputStream(f), (int) f.length());

    pst.setInt(9, id);

    int rowsUpdated = pst.executeUpdate();
    if (rowsUpdated > 0) {
        JOptionPane.showMessageDialog(null, "Successfully Updated");
        update();
    }
} catch (Exception e) {
    e.printStackTrace();
}

    }//GEN-LAST:event_UpdateActionPerformed

    private void SearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchKeyReleased
        // TODO add your handling code here:
          try 
        { 
           Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
            Statement st = con.createStatement() ; 
            String sql =  "select * from record where ProductCode like '%"+Search.getText()+"%' OR Quantity like '%"+Search.getText()+"%' OR Price like '%"+Search.getText()+"%' OR Duration like '%"+Search.getText()+"%' OR ProductName like '%"+Search.getText()+"%'"; 
            ResultSet rs = st.executeQuery(sql); 
            DefaultTableModel model = (DefaultTableModel)Tab.getModel();
            model.setRowCount(0);
            while(rs.next()) 
            { 
                String ProductCode= String.valueOf(rs.getInt("ProductCode")); 
                
                String ProductName = rs.getString("ProductName"); 
                String Quantity = rs.getString("Quantity"); 
                String Price = rs.getString("Price"); 
                String Duration = rs.getString("Duration"); 
                 
                String tbData[] = {ProductCode,ProductName,Quantity,Price,Duration}; 
                 
                model.addRow(tbData);
                 byte[] imagedata = rs.getBytes("ImageFile"); 
             format = new ImageIcon(imagedata); 
             Image mm = format.getImage(); 
             Image img2 = mm.getScaledInstance(200, 200, Image.SCALE_SMOOTH); 
             ImageIcon image = new ImageIcon(img2); 
             ImageLabel.setIcon(image);
             
               
            }
            con.close(); 
            
        }
         catch (Exception e) {
    e.printStackTrace();
         }
    }//GEN-LAST:event_SearchKeyReleased

    private void Tab1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Tab1MouseClicked
        // TODO add your handling code here:
     try {
    int id = Integer.parseInt(Tab1.getValueAt(Tab1.getSelectedRow(), 0).toString());

    Class.forName("com.mysql.cj.jdbc.Driver");
    String jdbcUrl = "jdbc:mysql://localhost:3306/db";
    String dbUser = "root";
    String dbPassword = "";

    try (Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
         PreparedStatement ps = con.prepareStatement("SELECT ProductCode, ProductName, Quantity, Price, Duration, StudentID FROM requests WHERE ProductCode=?")) {

        // Use PreparedStatement to avoid SQL injection
        ps.setInt(1, id);

        try (ResultSet res = ps.executeQuery()) {
            while (res.next()) {
                ProductCode2.setText(String.valueOf(res.getInt("ProductCode")));
                ProductName1.setText(res.getString("ProductName"));
                // ImageName.setText(res.getString("ImageName"));
                Quantity1.setText(res.getString("Quantity"));
                Price1.setText(res.getString("Price"));
                Duration2.setText(res.getString("Duration"));
                StudentID.setText(res.getString("StudentID"));
            }
        }
    }
} catch (SQLException | ClassNotFoundException | NumberFormatException e) {
    // Handle exceptions more gracefully (e.g., display an error message)
    e.printStackTrace();
}

        
    }//GEN-LAST:event_Tab1MouseClicked

    private void Search1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Search1KeyReleased
        // TODO add your handling code here:
       try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "");
    Statement st = con.createStatement();
    
    // Corrected the SQL query string
    String searchValue = Search1.getText();
    String sql = "SELECT * FROM requests WHERE StudentID LIKE '%" + searchValue + "%' OR " +
                 "ProductCode LIKE '%" + searchValue + "%' OR " +
                 "Quantity LIKE '%" + searchValue + "%' OR " +
                 "Price LIKE '%" + searchValue + "%' OR " +
                 "Duration LIKE '%" + searchValue + "%' OR " +
                 "ProductName LIKE '%" + searchValue + "%'";
    
    ResultSet rs = st.executeQuery(sql);
    DefaultTableModel model = (DefaultTableModel) Tab1.getModel();
    model.setRowCount(0);
    
    while (rs.next()) {
        String ProductCode = rs.getString("ProductCode"); // Removed extra parenthesis
        
        String ProductName = rs.getString("ProductName");
        String Quantity = rs.getString("Quantity");
        String Price = rs.getString("Price");
        String Duration = rs.getString("Duration");
        String StudentID = rs.getString("StudentID");
        
        String tbData[] = {ProductCode, ProductName, Quantity, Price, Duration, StudentID};
        model.addRow(tbData);
    }
    
    con.close();
} catch (Exception e) {
    e.printStackTrace();
}

    }//GEN-LAST:event_Search1KeyReleased

    private void Search1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Search1ActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
         int id = Integer.parseInt(Tab1.getValueAt(Tab1.getSelectedRow(),0).toString()); 
               
      try {
           
    Class.forName("com.mysql.cj.jdbc.Driver");
    String jdbcUrl = "jdbc:mysql://localhost:3306/db";
    String dbUser = "root";
    String dbPassword = "";
    Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
    Statement st = con.createStatement() ; 
    int r = JOptionPane.showConfirmDialog(this,"Want to accept? "); 
   if (r==0) { 
       if (!st.execute("delete from requests where ProductCode="+id)) { 
           update2() ; 
           
       
       }
       else JOptionPane.showMessageDialog(this,"try again");
       }
   
     
            
            
        }
      catch (Exception e) {
    e.printStackTrace();
}
    }//GEN-LAST:event_jButton1ActionPerformed

    private void QuantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_QuantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_QuantityActionPerformed

    private void pic1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic1MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField1.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();

    }//GEN-LAST:event_pic1MouseClicked

    private void pic3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic3MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField3.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic3MouseClicked

    private void pic7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic7MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField7.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic7MouseClicked

    private void pic8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic8MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField8.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic8MouseClicked

    private void pic2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic2MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField2.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic2MouseClicked

    private void pic4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic4MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField4.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic4MouseClicked

    private void pic5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic5MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField5.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic5MouseClicked

    private void pic9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic9MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField9.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic9MouseClicked

    private void pic6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic6MouseClicked
        // TODO add your handling code here:
        String productCode = jTextField6.getText();

        // Define variables to store product information
        String productName = "";
        String price = "";
        String quantity = "";
        String duration = "";

        // Execute a database query to retrieve the product information
        String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

        try {
            PreparedStatement preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, productCode);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                productName = resultSet.getString("ProductName");
                quantity = resultSet.getString("Quantity");
                price = resultSet.getString("Price");
                duration = resultSet.getString("Duration");
            }

            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Create a new Order frame with the retrieved product information
        new Order(productCode,productName, price, quantity, duration).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_pic6MouseClicked

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void Search2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Search2KeyReleased
        // TODO add your handling code here:
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Use the correct driver class name for MySQL 8+
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "");
            Statement st = con.createStatement();
            String sql = "select ProductCode, ImageFile from record where ProductName like '%" + Search1.getText() + "%'";
            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {
                pic1.setVisible(false);
                jTextField1.setVisible(false);
                pic2.setVisible(false);
                jTextField2.setVisible(false);
                pic3.setVisible(false);
                jTextField3.setVisible(false);
                pic4.setVisible(false);
                jTextField4.setVisible(false);
                pic5.setVisible(false);
                jTextField5.setVisible(false);
                pic6.setVisible(false);
                jTextField6.setVisible(false);
                pic7.setVisible(false);
                jTextField7.setVisible(false);
                pic8.setVisible(false);
                jTextField8.setVisible(false);
                pic9.setVisible(false);
                jTextField9.setVisible(false);
                byte[] imageBytes = rs.getBytes("ImageFile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic1.setVisible(true);
                jTextField1.setVisible(true);
                pic1.setIcon(new ImageIcon(scaledImage));
                jTextField1.setText(rs.getString("ProductCode"));
                pic2.setVisible(false);
                jTextField2.setVisible(false);
                pic3.setVisible(false);
                jTextField3.setVisible(false);
                pic4.setVisible(false);
                jTextField4.setVisible(false);
                pic5.setVisible(false);
                jTextField5.setVisible(false);
                pic6.setVisible(false);
                jTextField6.setVisible(false);
                pic7.setVisible(false);
                jTextField7.setVisible(false);
                pic8.setVisible(false);
                jTextField8.setVisible(false);
                pic9.setVisible(false);
                jTextField9.setVisible(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_Search2KeyReleased

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void ProductCode2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductCode2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductCode2ActionPerformed

    private void ProductName1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductName1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductName1ActionPerformed

    private void Price1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Price1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Price1ActionPerformed

    private void StudentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentIDActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // TODO add your handling code here:
        txtbill.setText(txtbill.getText()+ProductCode2.getText()+"-"+ProductName1.getText()+"/t/t"+Quantity1.getText()+"\n"+Price1.getText()+"\n"+Duration2.getText()+"\n"+StudentID.getText()+"");
        ProductCode2.setText("");
        ProductName1.setText("");
        Quantity1.setText("");
        Price1.setText(""); 
        Duration2.setText(""); 
        StudentID.setText("");
        
        

    }//GEN-LAST:event_addActionPerformed

    private void printActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printActionPerformed
        // TODO add your handling code here:
        try{
            txtbill.setText(txtbill.getText()+"Thank you");
            txtbill.print();

        }
        catch(Exception e )
        {

        }
    }//GEN-LAST:event_printActionPerformed

    private void Search2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Search2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public  void update() 
    {
         try 
        { 
           Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
            Statement st = con.createStatement() ; 
            String sql =  "select * from record"; 
            ResultSet rs = st.executeQuery(sql); 
            DefaultTableModel model = (DefaultTableModel)Tab.getModel();
            model.setRowCount(0);
            while(rs.next()) 
            { 
                String ProductCode = rs.getString("ProductCode"); 
                String ProductName = rs.getString("ProductName"); 
                String Quantity  = rs.getString("Quantity"); 
                String Price = rs.getString("Price");
                String Duration = rs.getString("Duration"); 
                
                
                String tbData[] = {ProductCode,ProductName,Quantity,Price,Duration}; 
                 
                model.addRow(tbData);
            }
            con.close(); 
            
        }
         catch (Exception e) {
    e.printStackTrace();
         }
    }
    public void update2()
    { 
         try 
        { 
           Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
            Statement st = con.createStatement() ; 
            String sql =  "select * from requests"; 
            ResultSet rs = st.executeQuery(sql); 
            DefaultTableModel model = (DefaultTableModel)Tab1.getModel();
            model.setRowCount(0);
            while(rs.next()) 
            { 
                String ProductCode = rs.getString("ProductCode"); 
                String ProductName = rs.getString("ProductName"); 
                String Quantity  = rs.getString("Quantity"); 
                String Price = rs.getString("Price");
                String Duration = rs.getString("Duration"); 
                String StudentID = rs.getString("StudentID"); 
                
                
                String tbData[] = {ProductCode,ProductName,Quantity,Price,Duration,StudentID}; 
                 
                model.addRow(tbData);
            }
            con.close(); 
            
        }
         catch (Exception e) {
    e.printStackTrace();
         }
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Adddmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Adddmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Adddmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Adddmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Adddmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Browse;
    private javax.swing.JButton Delete;
    private javax.swing.JTextField Duration;
    private javax.swing.JTextField Duration2;
    private javax.swing.JLabel ImageLabel;
    private javax.swing.JTextField ImageName;
    private javax.swing.JTextField ImagePath;
    private javax.swing.JButton Insert;
    private javax.swing.JTextField Price;
    private javax.swing.JTextField Price1;
    private javax.swing.JTextField ProductCode;
    private javax.swing.JTextField ProductCode2;
    private javax.swing.JTextField ProductName;
    private javax.swing.JTextField ProductName1;
    private javax.swing.JTextField Quantity;
    private javax.swing.JTextField Quantity1;
    private javax.swing.JTextField Search;
    private javax.swing.JTextField Search1;
    private javax.swing.JTextField Search2;
    private javax.swing.JTextField StudentID;
    private javax.swing.JTable Tab;
    private javax.swing.JTable Tab1;
    private javax.swing.JButton Update;
    private javax.swing.JButton add;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel pic1;
    private javax.swing.JLabel pic2;
    private javax.swing.JLabel pic3;
    private javax.swing.JLabel pic4;
    private javax.swing.JLabel pic5;
    private javax.swing.JLabel pic6;
    private javax.swing.JLabel pic7;
    private javax.swing.JLabel pic8;
    private javax.swing.JLabel pic9;
    private javax.swing.JButton print;
    private javax.swing.JTextArea txtbill;
    // End of variables declaration//GEN-END:variables
}
