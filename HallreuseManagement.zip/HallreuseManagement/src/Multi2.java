/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ASUS
 */
 import java.sql.*;
import javax.swing.JOptionPane;
 import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileNameExtensionFilter;
 import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class Multi2 extends javax.swing.JFrame {

    /**
     * Creates new form Multi2
     */
    
   
       
  

      File f = null ; 
    String path = null ; 
    private ImageIcon format = null ; 
    String fname = null ; 
    int s =0 ; 
    byte[] pimage = null ; 
    
    ResultSet rs ; 
     Connection con = null;
    PreparedStatement pst = null;
    public Multi2() {
        initComponents();
         // setExtendedState(JFrame.MAXIMIZED_BOTH);
       

        // Set layout for the JFrame
           setTitle("Product Images");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        // Initialize jLabel1 and jLabel2
        
        

        // Initialize the database connection (you need to set this up)
        con = initializeDatabaseConnection();

        // Retrieve and display images from the database
        displayImagesFromDatabase();
       
        con = NewClass.con() ; 
        update() ; 
    }
     private Connection initializeDatabaseConnection() {
        Connection con = null;
        try{
            Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
            //JOptionPane.showMessageDialog(null,"Connected" );
        }
        
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Wrong");
        }
       return con;
    }
      private void displayImagesFromDatabase() {
        try {
            // Execute a SQL query to fetch product data (image, product name, etc.) from your database
            String query = "SELECT ImageFile, ProductCode FROM record";
            PreparedStatement preparedStatement = con.prepareStatement(query);
            rs = preparedStatement.executeQuery();

            // Display the first image in jLabel1
             if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic1.setIcon(new ImageIcon(scaledImage));
                 jTextField1.setText(rs.getString("ProductCode"));
            }
              if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic2.setIcon(new ImageIcon(scaledImage));
                 jTextField2.setText(rs.getString("ProductCode"));
            }
               if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic3.setIcon(new ImageIcon(scaledImage));
                 jTextField3.setText(rs.getString("ProductCode"));
            }
                if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic4.setIcon(new ImageIcon(scaledImage));
                 jTextField4.setText(rs.getString("ProductCode"));
            }
                 if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic5.setIcon(new ImageIcon(scaledImage));
                 jTextField10.setText(rs.getString("ProductCode"));
            }
            if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic6.setIcon(new ImageIcon(scaledImage));
                jTextField6.setText(rs.getString("ProductCode"));
            }

            // Display the second image in jLabel2 if available
            if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic7.setIcon(new ImageIcon(scaledImage));
                 jTextField7.setText(rs.getString("ProductCode"));
            }
              if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic8.setIcon(new ImageIcon(scaledImage));
                 jTextField8.setText(rs.getString("ProductCode"));
            }
               if (rs.next()) {
                byte[] imageBytes = rs.getBytes("imagefile");
                BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
                BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
                Graphics2D g2d = scaledImage.createGraphics();
                g2d.drawImage(originalImage, 0, 0, 200, 200, null);
                g2d.dispose();
                pic9.setIcon(new ImageIcon(scaledImage));
                 jTextField9.setText(rs.getString("ProductCode"));
            }

            preparedStatement.close();
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
        


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        ProductCode1 = new javax.swing.JTextField();
        ProductName1 = new javax.swing.JTextField();
        Quantity1 = new javax.swing.JTextField();
        Price1 = new javax.swing.JTextField();
        Duration1 = new javax.swing.JTextField();
        Insert = new javax.swing.JButton();
        ImagePath1 = new javax.swing.JTextField();
        ImageLabel1 = new javax.swing.JLabel();
        ImageName1 = new javax.swing.JTextField();
        Browse = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Search = new javax.swing.JTextField();
        ProductCode = new javax.swing.JTextField();
        ProductName = new javax.swing.JTextField();
        Quantity = new javax.swing.JTextField();
        Price = new javax.swing.JTextField();
        Duration = new javax.swing.JTextField();
        ImageLabel = new javax.swing.JLabel();
        ImagePath = new javax.swing.JTextField();
        ImageName = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Tab = new javax.swing.JTable();
        StudentID = new javax.swing.JTextField();
        Place = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        pic1 = new javax.swing.JLabel();
        pic3 = new javax.swing.JLabel();
        pic7 = new javax.swing.JLabel();
        pic8 = new javax.swing.JLabel();
        pic2 = new javax.swing.JLabel();
        pic4 = new javax.swing.JLabel();
        pic5 = new javax.swing.JLabel();
        pic9 = new javax.swing.JLabel();
        pic6 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        Search1 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1500, 800));
        setMinimumSize(new java.awt.Dimension(1500, 800));

        jTabbedPane1.setFocusCycleRoot(true);
        jTabbedPane1.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N

        jPanel3.setMaximumSize(new java.awt.Dimension(400, 400));
        jPanel3.setPreferredSize(new java.awt.Dimension(400, 400));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ProductCode1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductCode1ActionPerformed(evt);
            }
        });
        jPanel3.add(ProductCode1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 100, 171, -1));

        ProductName1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductName1ActionPerformed(evt);
            }
        });
        jPanel3.add(ProductName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 50, 171, -1));

        Quantity1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Quantity1ActionPerformed(evt);
            }
        });
        jPanel3.add(Quantity1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 171, -1));

        Price1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Price1ActionPerformed(evt);
            }
        });
        jPanel3.add(Price1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 200, 171, -1));
        jPanel3.add(Duration1, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 250, 171, -1));

        Insert.setBackground(new java.awt.Color(204, 255, 153));
        Insert.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        Insert.setText("Give Your Product");
        Insert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertActionPerformed(evt);
            }
        });
        jPanel3.add(Insert, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 670, 345, 43));

        ImagePath1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImagePath1ActionPerformed(evt);
            }
        });
        jPanel3.add(ImagePath1, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 50, 215, 32));
        jPanel3.add(ImageLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 100, 215, 182));

        ImageName1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        ImageName1.setText("ImageName");
        ImageName1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImageName1ActionPerformed(evt);
            }
        });
        jPanel3.add(ImageName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 350, 215, -1));

        Browse.setBackground(new java.awt.Color(204, 204, 0));
        Browse.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        Browse.setText("Browse");
        Browse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BrowseActionPerformed(evt);
            }
        });
        jPanel3.add(Browse, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 300, 83, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(204, 255, 153));
        jLabel2.setText("Product Code");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 80, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 255, 153));
        jLabel3.setText("Quantity");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, 70, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 255, 153));
        jLabel4.setText("Price");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 70, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 255, 153));
        jLabel5.setText("Duration");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 60, -1));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 255, 153));
        jLabel1.setText("Product Name");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 90, -1));

        jLabel18.setText("jLabel18");
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1380, 790));

        jTabbedPane1.addTab("Insert Product", jPanel3);

        jPanel2.setMaximumSize(new java.awt.Dimension(2147483647, 2183647));
        jPanel2.setPreferredSize(new java.awt.Dimension(1500, 800));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Search.setBackground(new java.awt.Color(0, 51, 153));
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        Search.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                SearchKeyReleased(evt);
            }
        });
        jPanel2.add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 383, -1));

        ProductCode.setBackground(new java.awt.Color(0, 51, 153));
        ProductCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductCodeActionPerformed(evt);
            }
        });
        jPanel2.add(ProductCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 450, 170, -1));

        ProductName.setBackground(new java.awt.Color(0, 51, 153));
        ProductName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ProductNameActionPerformed(evt);
            }
        });
        jPanel2.add(ProductName, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 500, 170, -1));

        Quantity.setBackground(new java.awt.Color(0, 0, 153));
        jPanel2.add(Quantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 550, 170, -1));

        Price.setBackground(new java.awt.Color(0, 51, 153));
        Price.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PriceActionPerformed(evt);
            }
        });
        jPanel2.add(Price, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 600, 170, -1));

        Duration.setBackground(new java.awt.Color(0, 51, 153));
        jPanel2.add(Duration, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 650, 170, -1));
        jPanel2.add(ImageLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 100, 240, 220));

        ImagePath.setBackground(new java.awt.Color(0, 51, 153));
        ImagePath.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImagePathActionPerformed(evt);
            }
        });
        jPanel2.add(ImagePath, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 40, 236, -1));

        ImageName.setBackground(new java.awt.Color(0, 51, 153));
        ImageName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ImageNameActionPerformed(evt);
            }
        });
        jPanel2.add(ImageName, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 350, 250, -1));

        Tab.setBackground(new java.awt.Color(0, 51, 153));
        Tab.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        Tab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "SellerID", "ProductName", "Quantity", "Price", "Duration"
            }
        ));
        Tab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(Tab);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 110, 870, 260));

        StudentID.setBackground(new java.awt.Color(0, 51, 153));
        StudentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                StudentIDActionPerformed(evt);
            }
        });
        jPanel2.add(StudentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(1030, 670, 220, -1));

        Place.setBackground(new java.awt.Color(0, 51, 153));
        Place.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        Place.setText("Place Your Order");
        Place.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PlaceActionPerformed(evt);
            }
        });
        jPanel2.add(Place, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 710, 324, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Search Here");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, 80, 20));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel8.setText("Selected Product Details");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 390, 170, 20));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel9.setText("SellerID");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 450, 90, -1));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel10.setText("Product Name");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 500, 100, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel11.setText("Quantity");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 550, 100, -1));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel12.setText("Price");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 600, 120, -1));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel13.setText("Duration");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 650, 130, -1));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel14.setText("StudentID");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 670, 80, 20));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel15.setText("*Cnonfirm your order by \"Student ID\"");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 640, 270, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Rrr.jpg"))); // NOI18N
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1320, 800));

        jTabbedPane1.addTab("Search ", jPanel2);

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pic1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic1MouseClicked(evt);
            }
        });
        jPanel1.add(pic1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 40, 210, 209));

        pic3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic3MouseClicked(evt);
            }
        });
        jPanel1.add(pic3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 50, 220, 200));

        pic7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic7MouseClicked(evt);
            }
        });
        jPanel1.add(pic7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 530, 229, 188));

        pic8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic8MouseClicked(evt);
            }
        });
        jPanel1.add(pic8, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 530, 216, 187));

        pic2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic2MouseClicked(evt);
            }
        });
        jPanel1.add(pic2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 50, 216, 209));

        pic4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic4MouseClicked(evt);
            }
        });
        jPanel1.add(pic4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 310, 216, 178));

        pic5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic5MouseClicked(evt);
            }
        });
        jPanel1.add(pic5, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 320, 216, 169));

        pic9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic9MouseClicked(evt);
            }
        });
        jPanel1.add(pic9, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 540, 216, 178));

        pic6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pic6MouseClicked(evt);
            }
        });
        jPanel1.add(pic6, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 320, 216, 178));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, 210, -1));

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 270, 220, -1));

        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 280, 220, 20));
        jPanel1.add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 500, 220, -1));

        jTextField5.setText("jTextField5");
        jPanel1.add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 640, 216, 0));
        jPanel1.add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 510, 205, -1));
        jPanel1.add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 730, 236, -1));
        jPanel1.add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 730, 216, -1));

        jTextField9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField9ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 730, 216, -1));

        Search1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Search1KeyReleased(evt);
            }
        });
        jPanel1.add(Search1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 10, 406, -1));

        jLabel17.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Search your Product");
        jPanel1.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, -1, -1));

        jTextField10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField10ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField10, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 510, 165, -1));

        jLabel6.setText("L");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 0, 1080, 790));

        jButton1.setText("jButton1");
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 20, -1, -1));

        jButton2.setText("jButton2");
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 20, -1, -1));

        jButton3.setText("LogOut");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 10, -1, -1));

        jTabbedPane1.addTab("Home", jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1380, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        setSize(new java.awt.Dimension(1166, 807));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void SearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchKeyReleased
        // TODO add your handling code here:
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
            Statement st = con.createStatement() ;
            String sql =  "select * from record where ProductCode like '%"+Search.getText()+"%' OR Quantity like '%"+Search.getText()+"%' OR Price like '%"+Search.getText()+"%' OR Duration like '%"+Search.getText()+"%' OR ProductName like '%"+Search.getText()+"%'";
            ResultSet rs = st.executeQuery(sql);
            DefaultTableModel model = (DefaultTableModel)Tab.getModel();
            model.setRowCount(0);
            while(rs.next())
            {
                String ProductCode= String.valueOf(rs.getInt("ProductCode"));

                String ProductName = rs.getString("ProductName");
                String Quantity = rs.getString("Quantity");
                String Price = rs.getString("Price");
                String Duration = rs.getString("Duration");

                String tbData[] = {ProductCode,ProductName,Quantity,Price,Duration};

                model.addRow(tbData);
                byte[] imagedata = rs.getBytes("ImageFile");
                format = new ImageIcon(imagedata);
                Image mm = format.getImage();
                Image img2 = mm.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
                ImageIcon image = new ImageIcon(img2);
                ImageLabel.setIcon(image);

            }
            con.close();

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_SearchKeyReleased

    private void ProductNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductNameActionPerformed

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SearchActionPerformed

    private void ImagePathActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImagePathActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ImagePathActionPerformed

    private void ImageNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImageNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ImageNameActionPerformed
  public  void update() 
    {
         try 
        { 
           Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db","root","");
            Statement st = con.createStatement() ; 
            String sql =  "select * from record"; 
            ResultSet rs = st.executeQuery(sql); 
            DefaultTableModel model = (DefaultTableModel)Tab.getModel();
            model.setRowCount(0);
            while(rs.next()) 
            { 
                String ProductCode = rs.getString("ProductCode"); 
                String ProductName = rs.getString("ProductName"); 
                String Quantity  = rs.getString("Quantity"); 
                String Price = rs.getString("Price");
                String Duration = rs.getString("Duration"); 
                
                
                String tbData[] = {ProductCode,ProductName,Quantity,Price,Duration}; 
                 
                model.addRow(tbData);
            }
            con.close(); 
            
        }
         catch (Exception e) {
    e.printStackTrace();
         }
    }
    private void TabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabMouseClicked
        // TODO add your handling code here:
        int id = Integer.parseInt(Tab.getValueAt(Tab.getSelectedRow(),0).toString());
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String jdbcUrl = "jdbc:mysql://localhost:3306/db";
            String dbUser = "root";
            String dbPassword = "";

            try (Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);
                PreparedStatement ps = con.prepareStatement("SELECT * FROM record WHERE ProductCode="+id);
                ResultSet res = ps.executeQuery()) {

                while (res.next()) {

                    ProductCode.setText(res.getString("ProductCode"));
                    ProductName.setText(res.getString("ProductName"));
                    // ImageName.setText(res.getString("ImageName"));
                    Quantity.setText(res.getString("Quantity"));
                    Price.setText(res.getString("Price"));
                    Duration.setText(res.getString("Duration"));
                    ImagePath.setText(res.getString("ImagePath"));
                    byte[] imagedata = res.getBytes("ImageFile");
                    format = new ImageIcon(imagedata);
                    Image mm = format.getImage();
                    Image img2 = mm.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
                    ImageIcon image = new ImageIcon(img2);
                    ImageLabel.setIcon(image);

                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_TabMouseClicked

    private void StudentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_StudentIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_StudentIDActionPerformed

    private void PlaceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PlaceActionPerformed
        // TODO add your handling code here:
       

  
           try {
    Class.forName("com.mysql.cj.jdbc.Driver");
    String jdbcUrl = "jdbc:mysql://localhost:3306/db";
    String dbUser = "root";
    String dbPassword = "";
    Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

    PreparedStatement pst = con.prepareStatement("INSERT INTO requests(ProductCode, ProductName, Quantity, Price, Duration, StudentID) VALUES (?, ?, ?, ?, ?, ?)");
    
    pst.setString(1, ProductCode.getText());
    pst.setString(2, ProductName.getText());
    pst.setString(3, Quantity.getText());
    pst.setString(4, Price.getText());
    pst.setString(5, Duration.getText());
    pst.setString(6, StudentID.getText());

    int inserted = pst.executeUpdate();
    if (inserted > 0) {
        JOptionPane.showMessageDialog(null, "Successfully placed");
        update();
    }
} catch (SQLException e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
} catch (ClassNotFoundException e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
} finally {
    try {
        if (pst != null) {
            pst.close();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}



    }//GEN-LAST:event_PlaceActionPerformed

    private void ProductName1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductName1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductName1ActionPerformed

    private void InsertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertActionPerformed
        // TODO add your handling code here:
        System.out.print("Image Path - "+path);
        System.out.print("Image Name - "+ f.getName());
        File f = new File(path);
        try
        {
            InputStream is = new FileInputStream(f);
            pst = con.prepareStatement("INSERT INTO record(ProductCode,ProductName,Quantity,Price,Duration,ImagePath,ImageName,ImageFile)VALUES(?,?,?,?,?,?,?,?)");
            pst.setString(1,ProductCode1.getText());
            pst.setString(2,ProductName1.getText());

            pst.setString(3, Quantity1.getText());
            pst.setString(4,Price1.getText());
            pst.setString(5,Duration1.getText());
            pst.setString(6, path);
            pst.setString(7, f.getName());

            pst.setBlob(8,is );
            int inserted = pst.executeUpdate();
            if (inserted>0)
            {
                JOptionPane.showMessageDialog(null, "Successfully Inserted");
                update() ;
            }

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_InsertActionPerformed

    private void ImagePath1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImagePath1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ImagePath1ActionPerformed

    private void ImageName1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ImageName1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ImageName1ActionPerformed

    private void BrowseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BrowseActionPerformed
        // TODO add your handling code here:
        JFileChooser filechooser = new JFileChooser() ;
        FileNameExtensionFilter fnwf = new FileNameExtensionFilter("PNG JPG AND JPEG","png","jpeg","jpg");
        filechooser.addChoosableFileFilter(fnwf);
        int load = filechooser.showOpenDialog(null);
        if (load == filechooser.APPROVE_OPTION )
        {
            f = filechooser.getSelectedFile();
            path = f.getAbsolutePath();
            ImagePath1.setText(path);
            ImageIcon ii = new ImageIcon(path);
            Image img = ii.getImage().getScaledInstance(200,200,Image.SCALE_SMOOTH);
            ImageLabel1.setIcon(new ImageIcon(img));

        }
    }//GEN-LAST:event_BrowseActionPerformed

    private void ProductCode1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductCode1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductCode1ActionPerformed

    private void Price1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Price1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Price1ActionPerformed

    private void Quantity1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Quantity1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Quantity1ActionPerformed

    private void PriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PriceActionPerformed

    private void ProductCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ProductCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ProductCodeActionPerformed

    private void pic1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic1MouseClicked
        // TODO add your handling code here:
         String productCode = jTextField1.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
  
  
    }//GEN-LAST:event_pic1MouseClicked

    private void pic2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic2MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField2.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic2MouseClicked

    private void pic3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic3MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField3.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic3MouseClicked

    private void pic4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic4MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField4.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic4MouseClicked

    private void pic5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic5MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField10.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic5MouseClicked

    private void pic6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic6MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField6.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic6MouseClicked

    private void pic7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic7MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField7.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic7MouseClicked

    private void pic8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic8MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField8.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic8MouseClicked

    private void pic9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pic9MouseClicked
        // TODO add your handling code here:
            String productCode = jTextField9.getText(); 

    // Define variables to store product information
    String productName = "";
    String price = "";
    String quantity = "";
    String duration = "";

    // Execute a database query to retrieve the product information
    String query = "SELECT ProductName, Quantity, Price, Duration FROM record WHERE ProductCode = ?";

    try {
        PreparedStatement preparedStatement = con.prepareStatement(query);
        preparedStatement.setString(1, productCode);
        ResultSet resultSet = preparedStatement.executeQuery();

        if (resultSet.next()) {
            productName = resultSet.getString("ProductName");
            quantity = resultSet.getString("Quantity");
            price = resultSet.getString("Price");
            duration = resultSet.getString("Duration");
        }

        preparedStatement.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }

    // Create a new Order frame with the retrieved product information
    new Order(productCode,productName, price, quantity, duration).setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_pic9MouseClicked

    private void jTextField9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField9ActionPerformed

    private void Search1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Search1KeyReleased
        // TODO add your handling code here:
      try {
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "");
    Statement st = con.createStatement();
    String sql = "select ProductCode, ImageFile from record where ProductName like '%" + Search1.getText() + "%'";
    ResultSet rs = st.executeQuery(sql);

    if (rs.next()) {
        byte[] imageBytes = rs.getBytes("imagefile");
        BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
        BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
        Graphics2D g2d = scaledImage.createGraphics();
        g2d.drawImage(originalImage, 0, 0, 200, 200, null);
        g2d.dispose();

        pic1.setIcon(new ImageIcon(scaledImage));
        jTextField1.setText(rs.getString("ProductCode"));
    } else {
        // No results for the first pic1
    }

    if (rs.next()) {
        byte[] imageBytes = rs.getBytes("imagefile");
        BufferedImage originalImage = ImageIO.read(new ByteArrayInputStream(imageBytes));
        BufferedImage scaledImage = new BufferedImage(200, 200, originalImage.getType());
        Graphics2D g2d = scaledImage.createGraphics();
        g2d.drawImage(originalImage, 0, 0, 200, 200, null);
        g2d.dispose();

        pic2.setIcon(new ImageIcon(scaledImage));
        jTextField2.setText(rs.getString("ProductCode"));
    } else {
        // No results for the second pic2
    }

} catch (Exception e) {
    e.printStackTrace();
}

    }//GEN-LAST:event_Search1KeyReleased

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField10ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        //new Frame2().setVisible(true); 
        this.dispose(); 
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Multi2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Multi2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Multi2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Multi2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Multi2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Browse;
    private javax.swing.JTextField Duration;
    private javax.swing.JTextField Duration1;
    private javax.swing.JLabel ImageLabel;
    private javax.swing.JLabel ImageLabel1;
    private javax.swing.JTextField ImageName;
    private javax.swing.JTextField ImageName1;
    private javax.swing.JTextField ImagePath;
    private javax.swing.JTextField ImagePath1;
    private javax.swing.JButton Insert;
    private javax.swing.JButton Place;
    private javax.swing.JTextField Price;
    private javax.swing.JTextField Price1;
    private javax.swing.JTextField ProductCode;
    private javax.swing.JTextField ProductCode1;
    private javax.swing.JTextField ProductName;
    private javax.swing.JTextField ProductName1;
    private javax.swing.JTextField Quantity;
    private javax.swing.JTextField Quantity1;
    private javax.swing.JTextField Search;
    private javax.swing.JTextField Search1;
    private javax.swing.JTextField StudentID;
    private javax.swing.JTable Tab;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel pic1;
    private javax.swing.JLabel pic2;
    private javax.swing.JLabel pic3;
    private javax.swing.JLabel pic4;
    private javax.swing.JLabel pic5;
    private javax.swing.JLabel pic6;
    private javax.swing.JLabel pic7;
    private javax.swing.JLabel pic8;
    private javax.swing.JLabel pic9;
    // End of variables declaration//GEN-END:variables
}
